<?php
$x = 1;

while($x <= 5) {
    echo "Nomor sekarang adalah : $x <br>";
    $x++;
}
?>