<?php
    $hari = " Rabu ";

    if ($hari == " Kamis ") {
        echo  " Ini Hari Kamis ";
    }elseif($hari == " Jumat ") {
        echo " Ini Hari Jumat ";
    }else {
        echo " Ini Hari Rabu ";
    }
?>