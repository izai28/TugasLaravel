<?php

    $x = 1;
    do{
        echo "Perulangan ke $x <br>";
        $x++;
    }while($x <= -1);

?>