<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Belajar PHP</title>
</head>
<body>
    <h1> Selamat Belajar PHP</h1>
    <?php
        echo "<p>Hello Wordl, I'am PHP</p>";
    ?>
</body>
</html>