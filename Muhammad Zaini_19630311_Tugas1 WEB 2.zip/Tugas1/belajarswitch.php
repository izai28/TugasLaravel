<?php
    $hari = ' Rabu ';

    switch ($hari) {
        case ' Rabu ' :
            echo " Ini Hari Rabu " ;
            break;
        case 'Kamis' :
            echo " Ini Hari Kamis " ;
            break;
        default:
            echo " Ini Hari Ketemu " ;
            break;
    }
?>