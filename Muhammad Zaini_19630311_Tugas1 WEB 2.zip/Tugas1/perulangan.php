<?php

    for($i = 0; $i <= 100; $i++)
    {
        echo "Ini Adalah Perulangan ke <b>$i</b> <br>";
    }

?>