<?php

    function jumlah($x, $y)
    {
        $hasil = $x + $y;
        return $hasil;
    }

    $hitung = jumlah(5,7);
    echo " hasil penjumlahannya adalah : ".$hitung;
?>