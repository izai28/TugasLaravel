<?php
    function manusia($nama, $umur)
    {
        echo " Hallo ".$nama." umur kamu adalah ".$umur." tahun ";
    }
        // panggil functionnya
    manusia("Zaini",19);
?>