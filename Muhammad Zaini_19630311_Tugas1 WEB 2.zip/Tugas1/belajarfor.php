<?php
$x = 5;

for ($i=1; $i <= $x; $i++) {
    echo "Nomor sekarang adalah : $i <br>";
}
?>