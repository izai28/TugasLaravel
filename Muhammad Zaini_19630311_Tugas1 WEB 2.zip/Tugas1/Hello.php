<?php
    echo "<h2>Hello World, Selamat Belajar PHP.</h2>";
    
?>