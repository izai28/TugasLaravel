<?php
    $nilai = 80;

    switch ($nilai) {
        case 80:
           echo "Nilai A";
           break;
        
        case 70:
            echo "Nilai B";
            break;

        case 50:
            echo "Nilai C";
            break;
        default:
        echo "Nilai Tidak Terdaftar";
        break;
    }

?>