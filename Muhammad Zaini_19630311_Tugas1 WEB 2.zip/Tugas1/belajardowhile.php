<?php
$x = 1;

do {
    echo "Nomor sekarang adalah : $x <br>";
    $x++;
} while ($x <= 5);
?>